# Read Me

### Author J. H.
This is very much a work in progress.

### features to be added
- score board
- timer (basic form)
- victory screen (basic form)
- sounds
- animations
- Set score limit in app (basic form)

Images in the 'image_files' are from free 3rd party website. I do not own them.

### How to play
grab your horse and lets go! The goal of the game is simple. Caputre your opponents pawn with your knight and return it to your queen. 
Use the wasd keys to move the black knight and the arrow keys to move the white knight. Movement is determined by a 2 input combo.
Should both players attempt to move to the same square they will drop what ever flags they are holding and be bounced to a random square,
(any flags that the players were holding when they bounce are also bounced to a random square.)
up -> left is not the same movement as left -> up.

### Movement example White:
Take this starting position for white. depending on the order of your inputs the knight will move 2 spaces in the direction of your first input
and then 1 space in the direction of your second input. Repeating the same input or inputing an imposible move order (left + right for example) will reset
your move order.
![Screenshot 2025-03-25 003638](https://github.com/user-attachments/assets/4362c36e-033d-4fd8-bb00-f1e746fb71d0)


- this is an example of what up -> left would look like for white.
![Screenshot 2025-03-25 003649](https://github.com/user-attachments/assets/402db0ff-a30c-4e90-ae7d-6e100a474491)

-this is left -> up
![Screenshot 2025-03-25 003702](https://github.com/user-attachments/assets/37606535-583c-462d-831f-725d7dec6006)

### Black screen (Older build version)
If you are getting a blank window when you run this program it is because you must input a score limit into the terminal before the game opens.
<<<<<<< HEAD
![Screenshot 2025-03-25 004615](https://github.com/user-attachments/assets/5888fd67-ecb6-4a2f-b8f6-a9390093d01c)



>>>>>>> febe002a8bcaa78d577a1eb4be7f3c39b01b2414
